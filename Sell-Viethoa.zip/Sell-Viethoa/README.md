[![](https://poggit.pmmp.io/shield.state/Sell)](https://poggit.pmmp.io/p/RedSkyBlock)
[![](https://poggit.pmmp.io/shield.api/Sell)](https://poggit.pmmp.io/p/RedSkyBlock)
[![](https://poggit.pmmp.io/shield.dl.total/Sell)](https://poggit.pmmp.io/p/RedSkyBlock)


## About
> This is a plugin that helps your server sell items on hand or in inventory

## Features
- [x] Sell Hand
- [x] Sell All
- [x] Language Editing
- [x] Ease Setup

## Commands
| **NAME** | **DESCRIPTION** | **PERMISSION** |
|----------------|------------------------|-----------------------|
|***/sell hand***|***Sell ​​items on hand***|***sell.sell.command***| 
|***/sell all***|***Sell ​​all items in the inventory***|***sell.sell.command***|

## Download
>  Click the "Direct Download" button, then move the downloaded file to the "plugins" folder, make sure you have the EconomyAPI plugin.

## No EconomyAPI plugin?
> Don't worry, just click here [EconomyAPI](https://poggit.pmmp.io/p/EconomyAPI/5.7.3-PM4)
